const price = document.getElementById("price");
const state = document.getElementById("state");
const size = document.getElementById("size");
const seller = document.getElementById("seller");
const title = document.getElementById("title");
const itemImg = document.querySelector("#itemImg img");
const explain = document.getElementById("explain");

window.onload = async ()=>{
    let imgUrl = localStorage.getItem("imgUrl");
    await axios({
        method:"POST",
        url:"http://18.216.67.134:5000/User/login/refresh",
        headers:{
            "Authorization": `Bearer ${localStorage.getItem("refreshToken")}`,
        }
    }).then((e)=>{
        localStorage.setItem("token",e.data.access_token);
    }).catch((e)=>{
        alert("다시 로그인을 해주세요.");
        location.href="../login/login.html";
    })

    await axios({
        method:"GET",
        url:`http://18.216.67.134:5000/Cloth/Specific${imgUrl}`
    }).then((e)=>{
        setData(e.data);
    })
    .catch(()=>{
        alert("옷을 고르고 접근해주세요.");
    });

}



function setData(e){
    title.innerText = e.title;
    itemImg.src = `http://18.216.67.134:5000/${e.image_url}`; 
    seller.innerText = e.name;
    // state.innerText = e.
    size.innerText = `사이즈 : ${e.size}`;
    explain.innerText = e.description;
    price.innerText = `${e.price}원`
}
