const footerItem = document.querySelectorAll(".footerItem");

footerItem[0].addEventListener("click",()=>{
    location.href="../view/view_mobile.html";
})

footerItem[1].addEventListener("click",()=>{
    location.href="../uploadItem/uploadItem_mobile.html";
})

footerItem[2].addEventListener("click",()=>{
    location.href="../search/search.html";
})

footerItem[3].addEventListener("click",()=>{
    location.href="../mypage/mypage_mobile.html";
})