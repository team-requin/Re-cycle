const login = document.getElementById("login");
const signup = document.getElementById("signup");

function accessTokenCheck(){
    const token = localStorage.getItem("token");
    console.log(token);
    if(token){
        alert("토큰 있음")
    }
}
function loginClick(){
    location.href="./login.html";
}

function signupClick(){
    location.href="./signup.html";
}

login.addEventListener("click",loginClick);
signup.addEventListener("click",signupClick);

window.onload = ()=>{
    accessTokenCheck();
}